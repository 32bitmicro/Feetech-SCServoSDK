/*
 * SCServo.h
 * 飞特串行舵机接口
 * 日期: 2021.3.11
 * 作者: 
 */

#ifndef _SCSERVO_H
#define _SCSERVO_H

#include "SCSCL.h"
#include "SMS_STS.h"

#endif