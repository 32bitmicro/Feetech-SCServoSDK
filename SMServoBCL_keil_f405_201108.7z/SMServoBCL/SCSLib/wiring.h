#ifndef _WIRING_
#define _WIRING_

#include <stdint.h>

extern uint32_t millis(void);
extern void delay(uint32_t dwMs);


#endif /* _WIRING_ */
