/*
恒速模式例子在SMS40BL中测试通过，舵机出厂速度单位V=0为停止状态
*/

#include "stm32f10x.h"
#include "SCServo.h"
#include "uart.h"
#include "wiring.h"


void setup()
{
  Uart_Init(115200);
  delay(1000);
  WheelMode(1);//恒速模式
}

void loop()
{
  WriteSpe(1, 4000, 100);//舵机(ID1)以最高速度V=80(50*80步/秒)，加速度A=100(100*100步/秒^2)，旋转
  delay(2000);
  WriteSpe(1, 0, 100);//舵机(ID1)以加速度A=100(100*100步/秒^2)，停止旋转(V=0)
  delay(2000);
  WriteSpe(1, -4000, 100);//舵机(ID1)以最高速度V=-80(-50*80步/秒)，加速度A=100(100*100步/秒^2)，反向旋转
  delay(2000);
  WriteSpe(1, 0, 100);//舵机(ID1)以加速度A=100(100*100步/秒^2)，停止旋转(V=0)
  delay(2000);
}
