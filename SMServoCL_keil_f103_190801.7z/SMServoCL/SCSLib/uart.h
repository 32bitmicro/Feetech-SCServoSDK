#ifndef		_UART_H
#define		_UART_H

#include <stdint.h>
extern void servoUartInit(uint32_t baudRate);
extern void debugUartInit(uint32_t baudRate);
extern void uartFlush(void);
extern int16_t uartRead(void);
extern void uartWrite(uint8_t *buf , uint8_t len);

#endif
