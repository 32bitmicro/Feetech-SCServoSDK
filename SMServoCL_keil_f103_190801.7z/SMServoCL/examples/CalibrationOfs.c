/*
��λУ׼����
*/

#include <stdio.h>
#include "stm32f10x.h"
#include "SCServo.h"
#include "uart.h"
#include "wiring.h"

void setup()
{
	servoUartInit(115200);
	debugUartInit(115200);
  delay(1000);
}

void loop()
{
  CalibrationOfs(1);
  while(1);
}
