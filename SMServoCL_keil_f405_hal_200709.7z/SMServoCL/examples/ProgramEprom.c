/*
舵机参数编程
*/

#include "stm32f4xx.h"
#include "SCServo.h"
#include "uart.h"

void setup()
{
	Uart_Init(115200);
	HAL_Delay(1000);
	unLockEprom(1);//打开EPROM保存功能
  writeByte(1, SMSCL_ID, 2);//ID
	LockEprom(2);//关闭EPROM保存功能
}

void loop()
{

}
