﻿/*
以下例子在SMS40BL中测试通过，舵机出厂速度单位为0.732rpm，舵机机运行速度V=80
如果使用的出厂速度单位是0.0146rpm，则速度改为V=4000，延时公式T=[(P1-P0)/V]*1000+[V/(A*100)]*1000
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using SCServo.Def;
using SCServo.Comm;
using SCServo.Scs;
using SCServo.Smsbl;
using System.Threading;

namespace SCServo_CSharp
{
    class WritePos
    {
        static void Main(string[] args)
        {
            SerialCom _serialCom = new SerialCom();
            SMSBL sm = new SMSBL(_serialCom);
            if(!_serialCom.Open("COM3", 115200)){
                Console.WriteLine("Failed to init smsbl motor!");
		        Console.ReadKey();
                return;
            }
            while(true){
		        sm.WritePosEx(1, 4095, 80, 100);//舵机(ID1)以最高速度V=80(50*80步/秒)，加速度A=100(100*100步/秒^2)，运行至P1=4095位置
                Console.WriteLine("pos = 4095");
                Thread.Sleep(1495);//[(P1-P0)/(50*V)]*1000+[(50*V)/(A*100)]*1000

		        sm.WritePosEx(1, 0, 80, 100);//舵机(ID1)以最高速度V=80(50*80步/秒)，加速度A=100(100*100步/秒^2)，运行至P0=0位置
                Console.WriteLine("pos = 0");
                Thread.Sleep(1495);//[(P1-P0)/(50*V)]*1000+[(50*V)/(A*100)]*1000
	        }
            _serialCom.Close();
        }
    }
}
