using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using SCServo.Def;
using SCServo.Comm;
using SCServo.Scs;
using SCServo.Smsbl;
using System.Threading;

namespace SCServo_CSharp
{
    class CalibrationOfs
    {
        static void Main(string[] args)
        {
            SerialCom _serialCom = new SerialCom();
            SMSBL sm = new SMSBL(_serialCom);
            if (!_serialCom.Open("COM3", 115200))
            {
                Console.WriteLine("Failed to init smsbl motor!");
                Console.ReadKey();
                return;
            }
            sm.CalibrationOfs(1);
            Console.WriteLine("Calibration Ofs");
            _serialCom.Close();
            Console.ReadKey();
        }
    }
}


