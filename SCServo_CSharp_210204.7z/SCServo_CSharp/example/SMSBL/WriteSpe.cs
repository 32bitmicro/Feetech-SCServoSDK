﻿/*
以下例子在SMS40BL中测试通过，舵机出厂速度单位V=0为停止状态
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using SCServo.Def;
using SCServo.Comm;
using SCServo.Scs;
using SCServo.Smsbl;
using System.Threading;

namespace SCServo_CSharp
{
    class WriteSpe
    {
        static void Main(string[] args)
        {
            SerialCom _serialCom = new SerialCom();
            SMSBL sm = new SMSBL(_serialCom);
            if(!_serialCom.Open("COM3", 115200)){
                Console.WriteLine("Failed to init smsbl motor!");
		        Console.ReadKey();
                return;
            }
            sm.WheelMode(1);//恒速模式
            while(true){
                sm.WriteSpe(1, 80, 100);//舵机(ID1)以最高速度V=80(50*80步/秒)，加速度A=100(100*100步/秒^2)，旋转
                Console.WriteLine("speed = 80");
                Thread.Sleep(2000);

                sm.WriteSpe(1, 0, 100);//舵机(ID1)以加速度A=100(100*100步/秒^2)，停止旋转(V=0)
                Console.WriteLine("speed = 0");
                Thread.Sleep(2000);
                
                sm.WriteSpe(1, -80, 100);//舵机(ID1)以最高速度V=-80(-50*80步/秒)，加速度A=100(100*100步/秒^2)，反向旋转
                Console.WriteLine("speed = -80");
                Thread.Sleep(2000);

		        sm.WriteSpe(1, 0, 100);//舵机(ID1)以加速度A=100(100*100步/秒^2)，停止旋转(V=0)
                Console.WriteLine("speed = 0");
                Thread.Sleep(2000);
	        }
            _serialCom.Close();
        }
    }
}
