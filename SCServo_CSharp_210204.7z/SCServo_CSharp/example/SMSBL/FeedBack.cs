﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using SCServo.Def;
using SCServo.Comm;
using SCServo.Scs;
using SCServo.Smsbl;
using System.Threading;

namespace SCServo_CSharp
{
    class FeedBack
    {
        static void Main(string[] args)
        {
            SerialCom _serialCom = new SerialCom();
            SMSBL sm = new SMSBL(_serialCom);
            if(!_serialCom.Open("COM3", 115200)){
                Console.WriteLine("Failed to init smsbl motor!");
		        Console.ReadKey();
                return;
            }
            while(true){
		        int Pos;
		        int Speed;
		        int Load;
		        int Voltage;
		        int Temper;
		        int Move;
		        int Current;
		        if(sm.FeedBack(1)!=-1){
			        Pos = sm.ReadPos(-1);
			        Speed = sm.ReadSpeed(-1);
			        Load = sm.ReadLoad(-1);
			        Voltage = sm.ReadVoltage(-1);
			        Temper = sm.ReadTemper(-1);
			        Move = sm.ReadMove(-1);
			        Current = sm.ReadCurrent(-1);
                    Console.Write("FeedBack pos = ");
                    Console.WriteLine(Pos);
                    Console.Write("FeedBack Speed = ");
                    Console.WriteLine(Speed);
                    Console.Write("FeedBack Load = ");
                    Console.WriteLine(Load);
                    Console.Write("FeedBack Voltage = ");
                    Console.WriteLine(Voltage);
                    Console.Write("FeedBack Temper = ");
                    Console.WriteLine(Temper);
                    Console.Write("FeedBack Move = ");
                    Console.WriteLine(Move);
                    Console.Write("FeedBack Current = ");
                    Console.WriteLine(Current);
			        Thread.Sleep(10);
		        }else{
			        Console.WriteLine("read err =-1");
                    Thread.Sleep(2000);
		        }
		        Pos = sm.ReadPos(1);
		        if(Pos!=-1){
                    Console.Write("Pos = ");
                    Console.WriteLine(Pos);
			        Thread.Sleep(10);
		        }else{
			        Console.WriteLine("read position err");
			        Thread.Sleep(500);
		        }
        	
		        Voltage = sm.ReadVoltage(1);
		        if(Voltage!=-1){
                    Console.Write("Voltage = ");
                    Console.WriteLine(Voltage);
			        Thread.Sleep(10);
		        }else{
			        Console.WriteLine("read Voltage err");
			        Thread.Sleep(500);
		        }
        	
		        Temper = sm.ReadTemper(1);
		        if(Temper!=-1){
                    Console.Write("temperature = ");
                    Console.WriteLine(Temper);
			        Thread.Sleep(10);
		        }else{
			        Console.WriteLine("read temperature err");
			        Thread.Sleep(500);
		        }

		        Speed = sm.ReadSpeed(1);
		        if(Speed!=-1){
                    Console.Write("Speed = ");
                    Console.WriteLine(Speed);
			        Thread.Sleep(10);
		        }else{
			        Console.WriteLine("read Speed err");
			        Thread.Sleep(500);
		        }

		        Load = sm.ReadLoad(1);
		        if(Load!=-1){
                    Console.Write("Load = ");
                    Console.WriteLine(Load);
			        Thread.Sleep(10);
		        }else{
			        Console.WriteLine("read Load err");
			        Thread.Sleep(500);
		        }
        		
		        Current = sm.ReadCurrent(1);
		        if(Current!=-1){
                    Console.Write("Current = ");
                    Console.WriteLine(Current);
			        Thread.Sleep(10);
		        }else{
			        Console.WriteLine("read Current err");
			        Thread.Sleep(500);
		        }

		        Move = sm.ReadMove(1);
		        if(Move!=-1){
                    Console.Write("Move = ");
                    Console.WriteLine(Move);
			        Thread.Sleep(10);
		        }else{
			        Console.WriteLine("read Move err");
			        Thread.Sleep(500);
		        }
                Console.WriteLine();
		        Thread.Sleep(2000);
	        }
            _serialCom.Close();
        }
    }
}
