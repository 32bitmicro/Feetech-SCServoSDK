﻿/*
以下例子在SMS40BL中测试通过，舵机出厂速度单位V=0为停止状态
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using SCServo.Def;
using SCServo.Comm;
using SCServo.Scs;
using SCServo.Scscl;
using System.Threading;

namespace SCServo_CSharp
{
    class WritePWM
    {
        static void Main(string[] args)
        {
            SerialCom _serialCom = new SerialCom();
            SCSCL sc = new SCSCL(_serialCom);
            if(!_serialCom.Open("COM3", 1000000)){
                Console.WriteLine("Failed to init smsbl motor!");
		        Console.ReadKey();
                return;
            }
            sc.PWMMode(1);
            Console.WriteLine("mode = 1");
            while(true){
                sc.WritePWM(1, 500);
                Console.WriteLine("pwm = 500");
                Thread.Sleep(2000);

                sc.WritePWM(1, 0);
                Console.WriteLine("pwm = 0");
                Thread.Sleep(2000);

                sc.WritePWM(1, -500);
                Console.WriteLine("pwm = -500");
                Thread.Sleep(2000);

                sc.WritePWM(1, 0);
                Console.WriteLine("pwm = 0");
                Thread.Sleep(2000);
	        }
            _serialCom.Close();
        }
    }
}
