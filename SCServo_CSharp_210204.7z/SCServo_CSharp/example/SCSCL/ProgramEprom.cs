using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using SCServo.Def;
using SCServo.Comm;
using SCServo.Scs;
using SCServo.Scscl;
using System.Threading;

namespace SCServo_CSharp
{
    class ProgramEprom
    {
        static void Main(string[] args)
        {
            SerialCom _serialCom = new SerialCom();
            SCSCL sc = new SCSCL(_serialCom);
            if (!_serialCom.Open("COM3", 1000000))
            {
                Console.WriteLine("Failed to init smsbl motor!");
                Console.ReadKey();
                return;
            }
            sc.unLockEprom(1);//��EPROM���湦��
	        Console.WriteLine("unLock Eprom");
            sc.writeByte(1, (byte)SCSCLMem._ID, 2);//ID
	        Console.WriteLine("write ID:{0:D}", 2);
            sc.LockEprom(2);//�ر�EPROM���湦��
	        Console.WriteLine("Lock Eprom");
            _serialCom.Close();
            Console.ReadKey();
        }
    }
}


