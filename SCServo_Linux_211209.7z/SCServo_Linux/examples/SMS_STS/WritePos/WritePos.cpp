/*
舵机出厂速度单位为0.732rpm，舵机机运行速度V=80
舵机出厂速度单位是0.0146rpm，速度改为V=80*50
*/

#include <iostream>
#include "SCServo.h"

SMS_STS sm_st;

int main(int argc, char **argv)
{
	if(argc<2){
        std::cout<<"argc error!"<<std::endl;
        return 0;
	}
	std::cout<<"serial:"<<argv[1]<<std::endl;
    if(!sm_st.begin(115200, argv[1])){
        std::cout<<"Failed to init sms/sts motor!"<<std::endl;
        return 0;
    }
	while(1){
		sm_st.WritePosEx(1, 4095, 80, 100);//舵机(ID1)以最高速度V=80(50*80步/秒)，加速度A=100(100*100步/秒^2)，运行至P1=4095位置
		std::cout<<"pos = "<<4095<<std::endl;
		usleep(1495*1000);//[(P1-P0)/(50*V)]*1000+[(50*V)/(A*100)]*1000
  
		sm_st.WritePosEx(1, 0, 80, 100);//舵机(ID1)以最高速度V=80(50*80步/秒)，加速度A=100(100*100步/秒^2)，运行至P0=0位置
		std::cout<<"pos = "<<0<<std::endl;
		usleep(1495*1000);//[(P1-P0)/(50*V)]*1000+[(50*V)/(A*100)]*1000
	}
	sm_st.end();
	return 1;
}

